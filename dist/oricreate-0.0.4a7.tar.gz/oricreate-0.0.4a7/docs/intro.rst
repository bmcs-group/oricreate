============
Introduction
============

The package implements the algorithms
for the simulation support for design and manufacturing
of folded plate structures. It serves as a general
optimization solver that can dynamically combine
constraints and goal functions to constitute a design
pipeline. 

The model components include the rigid origami
simulator, potential energy  

