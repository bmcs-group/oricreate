

   
Vector angles
=============

.. automodule:: docs.howtos.ex02_vector_angles.ex02_vector_acos

.. include:: ex02_vector_acos.py
   :literal:
   :start-after: # end_doc

The output of the script looks as follows:

.. program-output:: python howtos/ex02_vector_angles/ex02_vector_acos.py

