
Crease pattern state and operators
==================================

Normal vectors 
--------------

.. automodule:: docs.howtos.ex04_cp_operators.yoshimura_facets_normals

.. include:: yoshimura_facets_normals.py
   :literal:
   :start-after: # begin
   :end-before: # end

The output of the script looks as follows:

.. program-output:: python howtos/ex04_cp_operators/yoshimura_facets_normals.py

The final configuration including the normals looks as follows:

.. plot:: howtos/ex04_cp_operators/yoshimura_facets_normals_plot.py
   :width: 400px
