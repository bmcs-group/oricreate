'''
Created on Oct 6, 2014

@author: rch
'''

import sympy as sm


r_, s_, x_, y_, z_, t_ = sm.symbols('r,s,x,y,z,t')
